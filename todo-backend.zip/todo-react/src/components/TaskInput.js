import React, { useEffect, useState } from "react";

function TaskInput({ addTask, isEditing, taskToEdit, taskInputRef }) {
  const [task, setTask] = useState("");

  useEffect(() => {
    if (taskToEdit) {
      setTask(taskToEdit.taskName);
      taskInputRef.current.focus();
    }
  }, [taskToEdit, taskInputRef]);

  const handleInputChange = (e) => {
    setTask(e.target.value);
  };

  const handleAddTask = () => {
    if (task.trim() === "") return;

    addTask(task);
    setTask("");
  };

  return (
    <div className="TaskInput"> {/* Add the class here */}
      <input
        type="text"
        value={task}
        onChange={handleInputChange}
        placeholder="Enter a task"
        ref={taskInputRef}
      />
      <button onClick={handleAddTask}>Add Task</button>
    </div>
  );
}

export default TaskInput;
