import React, { useState, useEffect, useRef } from 'react';
import Button from './Button';
import './Styles.css';
import ToastContainer from './ToastContainer';
import Tabs from './Tabs';
import TaskInput from './TaskInput';
import ConfirmationModal from './ConfirmationModal';
import Login from './Login';
import Signup from './Signup';

function Main() {
  const [tasks, setTasks] = useState([]);
  const [activeTab, setActiveTab] = useState('All');
  const [isEditing, setIsEditing] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState(null);
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [toastStatus, setToastStatus] = useState({ status: "", message: "" });
  const [showLogin, setShowLogin] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const taskListRef = useRef(null);
  const taskInputRef = useRef(null);

  useEffect(() => {
    const accessToken = sessionStorage.getItem('accessToken');
    setShowLogin(!accessToken);
    if (accessToken) {
      getTodos();
    }
  }, []);

  const handleLogout = () => {
    console.log("Logging out, clearing session data...");
    sessionStorage.clear();
    setShowLogin(true);
    setShowSignUp(false);
  };

  const handleSaveTask = async (taskName, taskId = null, status = 'In-progress') => {
    console.log(`handleSaveTask called with taskName: "${taskName}", taskId: ${taskId}, status: ${status}`);
    
    if (taskName.trim() === '') {
      setToastStatus({ status: "warning", message: "Task cannot be empty" });
      return;
    }
  
    // Check for duplicates before adding the new task
    const isDuplicate = tasks.some((task) => task.taskName.toLowerCase() === taskName.toLowerCase() && task.id !== taskId); // Ensure no duplicates with the same name
    if (isDuplicate) {
      setToastStatus({ status: "warning", message: "This task already exists" });
      return;
    }
  
    const newTask = {
      taskName,
      status,
    };
  
    console.log("New task object created:", newTask);
  
    try {
      const accessToken = sessionStorage.getItem('accessToken');
      const userId = sessionStorage.getItem('userId');
    
      if (!userId) {
        setToastStatus({ status: "warning", message: "User ID is missing" });
        return;
      }
  
      const endpoint = taskId
        ? `http://localhost:5000/api/tasks/${taskId}` // If editing, use PUT
        : 'http://localhost:5000/api/tasks'; // If creating, use POST
      const method = taskId ? 'PUT' : 'POST'; // Use PUT for editing, POST for new tasks
      const body = JSON.stringify(newTask);
  
      console.log(`API request to ${method} task at ${endpoint}`);
      
      const response = await fetch(endpoint, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'UserId': userId,
        },
        body,
      });
  
      const data = await response.json();
      console.log("API response:", data);
  
      if (data.status === "success") {
        setToastStatus({ status: "success", message: data.message });
  
        // After adding or updating a task, re-fetch the tasks to ensure the UI is updated immediately
        getTodos();  // Refetch tasks from the server
  
      } else {
        setToastStatus({ status: "failure", message: data.message });
      }
    } catch (error) {
      console.error('Error saving task:', error);
      setToastStatus({ status: "failure", message: "Error saving task to database" });
    }
  };
  

  

  const handleEditTask = (task) => {
    console.log('handleEditTask called with task:', task);
    setIsEditing(true);
    setTaskToEdit(task); // Set the task to be edited
  };

  const getTodos = async () => {
    try {
      const accessToken = sessionStorage.getItem('accessToken');
      const userId = sessionStorage.getItem('userId');
    
      const response = await fetch('http://localhost:5000/api/tasks', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'UserId': userId,
        },
      });
  
      if (!response.ok) {
        throw new Error(`Failed to fetch tasks: ${response.status}`);
      }
  
      const data = await response.json();
      if (data.status === 'success') {
        console.log('Fetched tasks:', data.data);
        setTasks(data.data.filter((task) => task.id)); // Ensure valid tasks are set
      } else if (data.message === 'Token Expired') {
        await getRefreshToken();
        return getTodos();
      }
    } catch (error) {
      console.error('Error while fetching tasks:', error);
    }
  };
  

  const getRefreshToken = async () => {
    try {
      const refreshToken = sessionStorage.getItem('refreshToken');
      const response = await fetch('http://localhost:5000/api/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${refreshToken}`,
          'UserId': sessionStorage.getItem('userId'),
        },
      });

      const data = await response.json();
      if (data.status === "success") {
        sessionStorage.setItem("accessToken", data.data.accessToken);
      } else {
        setToastStatus({ status: data.status, message: data.message });
        handleLogout();
      }
    } catch (error) {
      console.error('Error refreshing token:', error);
      setToastStatus({ status: "failure", message: "Error refreshing token" });
    }
  };

  const handleOpenDeleteDialog = (task) => {
    setTaskToDelete(task);
  };

  const handleConfirmDelete = () => {
    if (taskToDelete) {
      handleDeleteTask(taskToDelete);
    }
  };

  const handleDeleteTask = async (task) => {
    setTasks((prevTasks) => prevTasks.filter((t) => t.id !== task.id)); // Optimistic removal
  
    try {
      const accessToken = sessionStorage.getItem('accessToken');
      const response = await fetch(`http://localhost:5000/api/tasks/${task.id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'UserId': sessionStorage.getItem('userId'),
        },
      });

      const data = await response.json();
      if (data.status !== "success") {
        setToastStatus({ status: "failure", message: data.message });
        if (data.message === "Token Expired") {
          await getRefreshToken();
          return handleDeleteTask(task); // Retry with refreshed token
        }
        throw new Error(data.message);
      }
      setToastStatus({ status: "success", message: "Task deleted successfully" });
    } catch (error) {
      console.error('Error deleting task:', error);
      setToastStatus({ status: "failure", message: "Error deleting task" });
      setTasks((prevTasks) => [task, ...prevTasks]); // Revert if deletion fails
    }
  };

  const filteredTasks = tasks.filter((task) => {
    const taskStatus = task.status.toLowerCase();
    const activeTabLower = activeTab.toLowerCase();
    return (
      activeTabLower === 'all' ||
      (activeTabLower === 'in-progress' && taskStatus === 'in-progress') ||
      (activeTabLower === 'completed' && taskStatus === 'completed')
    );
  });

  return (
    <>
      {showSignUp ? (
        <Signup setShowSignUp={setShowSignUp} />
      ) : showLogin ? (
        <Login setShowLogin={setShowLogin} setShowSignUp={setShowSignUp} />
      ) : (
        <div className="MainContent">
          <div className="App">
            <header className="App-header">
              <h1>Todo List</h1>
              <Button label="Logout" className="logout-button" onClick={handleLogout} />
            </header>
            <TaskInput
              addTask={handleSaveTask}
              isEditing={isEditing}
              taskToEdit={taskToEdit}
              taskInputRef={taskInputRef}
              buttonText={isEditing ? "Save" : "Add Task"}
            />
            <Tabs
              activeTab={activeTab}
              onTabChange={setActiveTab}
              taskCounts={{
                all: tasks.length,
                inProgress: tasks.filter(task => task.status.toLowerCase() === 'in-progress').length,
                completed: tasks.filter(task => task.status.toLowerCase() === 'completed').length,
              }}
            />
            <ToastContainer toastStatus={toastStatus} />
            <div className="task-list-header">
              <h2>List of Tasks</h2>
            </div>
            {tasks.length === 0 ? (
              <p>No Tasks Available</p>
            ) : (
              <div className="task-list" ref={taskListRef}>
                {filteredTasks.map((task) => (
                  <div key={task.id} className="task-container">
                    <div className="task-content">
                      <input
                        type="checkbox"
                        checked={task.status.toLowerCase() === 'completed'}
                        onChange={() => {
                          const newStatus = task.status.toLowerCase() === 'in-progress' ? 'completed' : 'in-progress';
                          handleSaveTask(task.taskName, task.id, newStatus);
                          console.log(`Task status updated: ${task.taskName} -> ${newStatus}`);
                        }}
                      />
                      <p className={`task-name ${task.status.toLowerCase() === 'completed' ? 'completed' : ''}`}>
                        {task.taskName}
                      </p>
                      <div className="task-actions">
                        <Button label="Edit" className="edit-button" onClick={() => handleEditTask(task)} />
                        <Button label="Delete" className="delete-button" onClick={() => handleOpenDeleteDialog(task)} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <ConfirmationModal
              isOpen={taskToDelete !== null}
              onClose={() => setTaskToDelete(null)}
              onConfirm={handleConfirmDelete}
            />
          </div>
        </div>
      )}
    </>
  );
}

export default Main;
