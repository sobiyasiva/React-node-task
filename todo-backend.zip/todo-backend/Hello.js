console.log("Hello");
console.log('Hi Sobi');