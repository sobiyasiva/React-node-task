import React, { useState, useEffect } from 'react';

function TaskInput({ addTask, isEditing, taskToEdit, taskInputRef, buttonText }) {
  const [task, setTask] = useState("");

  useEffect(() => {
    if (taskToEdit) {
      setTask(taskToEdit.taskName);
      taskInputRef.current.focus();
    }
  }, [taskToEdit, taskInputRef]);

  const handleInputChange = (e) => {
    setTask(e.target.value);
  };

  const handleAddOrUpdateTask = () => {
    if (task.trim() === "") return;

    addTask(task, taskToEdit?.id); // Pass taskId if editing
    setTask("");
  };

  return (
    <div className="TaskInput">
      <input
        type="text"
        value={task}
        onChange={handleInputChange}
        placeholder="Enter a task"
        ref={taskInputRef}
      />
      <button onClick={handleAddOrUpdateTask}>{buttonText}</button>
    </div>
  );
}

export default TaskInput;
